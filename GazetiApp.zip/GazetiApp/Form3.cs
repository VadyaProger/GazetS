﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace GazetiApp
{
    public partial class Form3 : Form
    {
        public Model1 db { get; set; }

        public Agent ag { get; set; }
        public Form3()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Agent ag = new Agent();

            int AT;
            bool c = int.TryParse(textBox3.Text, out AT);
            if (c == false)
            {
                MessageBox.Show("Неверный формат ID типа агента");
                return;
            }

            int prior;
            bool d = int.TryParse(textBox6.Text, out prior);
            if (d == false)
            {
                MessageBox.Show("Неверный формат приоритета");
                return;
            }

            ag.Title = textBox2.Text;
            ag.AgentTypeID = AT;
            ag.INN = textBox4.Text;
            ag.Phone = textBox5.Text;
            ag.Priority = prior;

            try
            {
                db.SaveChanges();

                DialogResult = DialogResult.OK;
            }
            catch(Exception ex)
            {
                MessageBox.Show(ex.InnerException.InnerException.Message);
            }
        }

        private void Form3_Load(object sender, EventArgs e)
        {
            textBox2.Text = ag.Title;
            textBox3.Text = ag.AgentType.ToString();
            textBox4.Text = ag.INN;
            textBox5.Text = ag.Phone;
            textBox6.Text = ag.Priority.ToString();
        }
    }
}
