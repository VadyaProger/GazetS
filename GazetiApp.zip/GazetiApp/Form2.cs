﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace GazetiApp
{
    public partial class Form2 : Form
    {
        public Model1 db { get; set; }
        public Form2()
        {
            InitializeComponent();
        }

        private void Form2_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            Agent ag = new Agent();

            if (/*textBox1.Text == " " ||*/ textBox2.Text == " " || textBox3.Text == " " || textBox4.Text == " " || textBox5.Text == " " || textBox6.Text == " ")
            {
                MessageBox.Show("Нужно ввести все требуемые данные!");
                return;
            }

            //int id;
            //bool a = int.TryParse(textBox1.Text, out id);
            //if (a == false)
            //{
            //    MessageBox.Show("Неверный формат ID");
            //    return;
            //}

            int inn;
            bool b = int.TryParse(textBox4.Text, out inn);
            if (b == false)
            {
                MessageBox.Show("Неверный формат ИНН");
                return;
            }

            int AT;
            bool c = int.TryParse(textBox3.Text, out AT);
            if (c == false)
            {
                MessageBox.Show("Неверный формат ID типа агента");
                return;
            }

            int prior;
            bool d = int.TryParse(textBox6.Text, out prior);
            if (d == false)
            {
                MessageBox.Show("Неверный формат приоритета");
                return;
            }

            //ag.ID = id;
            ag.Title = textBox2.Text;
            ag.AgentTypeID = AT;
            ag.INN = textBox4.Text;
            ag.Phone = textBox5.Text;
            ag.Priority = prior;

            db.Agent.Add(ag);
            try
            {
                db.SaveChanges();

                DialogResult = DialogResult.OK;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.InnerException.InnerException.Message);
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
