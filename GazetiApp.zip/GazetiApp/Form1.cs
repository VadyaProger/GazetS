﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace GazetiApp
{
    public partial class Form1 : Form
    {
        Model1 db = new Model1();
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            agentBindingSource.DataSource = db.Agent.ToList();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Form2 f2 = new Form2();

            f2.db = db;

            DialogResult DR = f2.ShowDialog();
            if (DR == DialogResult.OK)
            {
                agentBindingSource.DataSource = db.Agent.ToList();
            }
        }

        private void button4_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Form3 f3 = new Form3();

            Agent ag = (Agent)agentBindingSource.Current;

            f3.db = db;
            f3.ag = ag;

            DialogResult DR = f3.ShowDialog();

            if(DR == DialogResult.OK)
            {
                agentBindingSource.DataSource = db.Agent.ToList();
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            Agent ag = (Agent)agentBindingSource.Current;

            DialogResult DR = MessageBox.Show("Вы действительно хотите удалить запись" + ag.ID.ToString(),
            "Удаление роли", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if(DR == DialogResult.Yes)
            {
                db.Agent.Remove(ag);
                try
                {
                    db.SaveChanges();
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
                agentBindingSource.DataSource = db.Agent.ToList();
            }
        }
    }
}
